# Deploy rápido (GitHub Pages ou Netlify)

## GitHub Pages
1. Crie um repositório (ex.: `atividade-funcao`).
2. Envie **index.html** para a branch `main`.
3. Em **Settings → Pages**, selecione **Deploy from branch** e a pasta raiz.
4. O site vai sair em: `https://SEU_USUARIO.github.io/atividade-funcao/`

## Netlify (drag & drop)
1. Acesse https://app.netlify.com/ → **Add new site → Deploy manually**.
2. Arraste o arquivo **index.html** (ou o **.zip** inteiro).
3. Ele gera um link `https://NOME.netlify.app` automático.

> Observação: este projeto é estático (apenas HTML/JS/CSS), então não precisa de build nem `package.json`.
